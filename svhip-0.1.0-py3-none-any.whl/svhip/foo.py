def foo(a,b):
    print(a+b)
    
